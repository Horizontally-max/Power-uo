# Hyphirion Honored One & Chosen One — Paper 1.21.10

Original abilities, not based on any anime or existing franchise.

## Build
Requires Java 21 and Gradle:
```bash
gradle build
```
The plugin JAR will be in `build/libs/`.

## Install
1. Build the project.
2. Upload the JAR to your Paper server's `plugins` folder.
3. Restart the server.

## Commands
- `/hc give <player> honored`
- `/hc give <player> chosen`
- `/hc remove <player>`
- `/hc help`

Rank commands require `honoredchosen.admin` (default: OP).

## Controls
While sneaking:
- Right-click: signature power
- Left-click: secondary power
- Swap hands (F): ultimate power

### Honored One
- Right-click: Celestial Step — teleport to the block you're looking at (up to 32 blocks), or forward if no block is targeted.
- Left-click: Divine Lightning — lightning effect and damage at the targeted entity/block.
- F: Divine Barrier — strong temporary resistance and fire resistance.

### Chosen One
- Right-click: Destiny Burst — short-range energy blast and knockback.
- Left-click: Chosen Might — temporary strength and speed.
- F: Fated Recovery — regeneration and absorption.

Cooldowns are built in. This project is source code and must be built into a JAR before server installation.

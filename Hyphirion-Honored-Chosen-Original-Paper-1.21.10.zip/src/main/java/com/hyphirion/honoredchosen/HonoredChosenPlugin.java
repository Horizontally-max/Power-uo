package com.hyphirion.honoredchosen;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import org.bukkit.util.Vector;

import java.util.*;

public final class HonoredChosenPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey rankKey;
    private final Map<String, Long> cooldowns = new HashMap<>();

    @Override public void onEnable() {
        rankKey = new NamespacedKey(this, "hyphirion_rank");
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("honoredchosen")).setExecutor(this);
        getLogger().info("Hyphirion HonoredChosen enabled.");
    }

    private String rank(Player p) {
        return p.getPersistentDataContainer().getOrDefault(rankKey, PersistentDataType.STRING, "");
    }

    private void giveRank(Player p, String rank) {
        p.getPersistentDataContainer().set(rankKey, PersistentDataType.STRING, rank);
        String label = rank.equals("honored") ? "HONORED ONE" : "CHOSEN ONE";
        ChatColor color = rank.equals("honored") ? ChatColor.AQUA : ChatColor.GOLD;
        p.setDisplayName(color + "[" + label + "] " + ChatColor.WHITE + p.getName());
        p.setPlayerListName(p.getDisplayName());
        p.sendTitle(color + label, ChatColor.GRAY + "Hyphirion SMP", 10, 50, 15);
        p.getWorld().playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.1f);
        p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0,1,0), 45, .7,.8,.7,.04);
        p.sendMessage(color + "You have been granted the " + label + " rank!");
    }

    private void removeRank(Player p) {
        p.getPersistentDataContainer().remove(rankKey);
        p.setDisplayName(null);
        p.setPlayerListName(null);
        p.sendMessage(ChatColor.YELLOW + "Your special rank has been removed.");
    }

    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.AQUA + "Hyphirion Honored One & Chosen One");
            sender.sendMessage(ChatColor.YELLOW + "/hc give <player> <honored|chosen>");
            sender.sendMessage(ChatColor.YELLOW + "/hc remove <player>");
            sender.sendMessage(ChatColor.YELLOW + "Sneak + Right-click: signature power");
            sender.sendMessage(ChatColor.YELLOW + "Sneak + Left-click: secondary power");
            sender.sendMessage(ChatColor.YELLOW + "Sneak + F: ultimate power");
            return true;
        }
        if (!sender.hasPermission("honoredchosen.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission.");
            return true;
        }
        if (args[0].equalsIgnoreCase("give")) {
            if (args.length < 3) { sender.sendMessage("/hc give <player> <honored|chosen>"); return true; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(ChatColor.RED + "Player must be online."); return true; }
            String r = args[2].toLowerCase(Locale.ROOT);
            if (!r.equals("honored") && !r.equals("chosen")) {
                sender.sendMessage(ChatColor.RED + "Rank must be honored or chosen."); return true;
            }
            giveRank(target, r);
            sender.sendMessage(ChatColor.GREEN + "Granted " + r + " rank to " + target.getName());
            return true;
        }
        if (args[0].equalsIgnoreCase("remove")) {
            if (args.length < 2) { sender.sendMessage("/hc remove <player>"); return true; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(ChatColor.RED + "Player must be online."); return true; }
            removeRank(target);
            sender.sendMessage(ChatColor.GREEN + "Removed rank from " + target.getName());
            return true;
        }
        sender.sendMessage(ChatColor.RED + "Unknown command. Use /hc help.");
        return true;
    }

    @EventHandler public void onInteract(PlayerInteractEvent event) {
        Player p = event.getPlayer();
        if (!p.isSneaking() || event.getHand() != EquipmentSlot.HAND || rank(p).isEmpty()) return;
        if (!p.hasPermission("honoredchosen.use") && !p.hasPermission("honoredchosen.admin")) return;
        if (event.getAction().isRightClick()) {
            event.setCancelled(true);
            useAbility(p, "signature");
        } else if (event.getAction().isLeftClick()) {
            event.setCancelled(true);
            useAbility(p, "secondary");
        }
    }

    @EventHandler public void onSwap(PlayerSwapHandItemsEvent event) {
        Player p = event.getPlayer();
        if (!p.isSneaking() || rank(p).isEmpty()) return;
        if (!p.hasPermission("honoredchosen.use") && !p.hasPermission("honoredchosen.admin")) return;
        event.setCancelled(true);
        useAbility(p, "ultimate");
    }

    private boolean cooldown(Player p, String ability, int seconds) {
        String key = p.getUniqueId() + ":" + ability;
        long now = System.currentTimeMillis();
        long until = cooldowns.getOrDefault(key, 0L);
        if (now < until) {
            p.sendActionBar(ChatColor.RED + "Power cooldown: " + ((until-now+999)/1000) + "s");
            return false;
        }
        cooldowns.put(key, now + seconds * 1000L);
        return true;
    }

    private void useAbility(Player p, String slot) {
        boolean honored = rank(p).equals("honored");
        String power = honored
                ? (slot.equals("signature") ? "teleport" : slot.equals("secondary") ? "lightning" : "invulnerability")
                : (slot.equals("signature") ? "energy" : slot.equals("secondary") ? "strength" : "regeneration");

        switch (power) {
            case "teleport" -> {
                if (!cooldown(p, power, 5)) return;
                var target = p.getTargetBlockExact(32);
                Location destination;
                if (target != null) destination = target.getLocation().add(0.5, 1.0, 0.5);
                else destination = p.getLocation().add(p.getLocation().getDirection().multiply(8));
                destination.setYaw(p.getLocation().getYaw());
                destination.setPitch(p.getLocation().getPitch());
                p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0,1,0), 60, .6,.8,.6,.2);
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                p.teleport(destination);
                p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0,1,0), 60, .6,.8,.6,.1);
                p.sendMessage(ChatColor.AQUA + "Celestial Step!");
            }
            case "lightning" -> {
                if (!cooldown(p, power, 8)) return;
                var target = p.getTargetEntity(32);
                Location loc = target != null ? target.getLocation() : p.getTargetBlockExact(32) != null
                        ? p.getTargetBlockExact(32).getLocation() : p.getLocation().add(p.getLocation().getDirection().multiply(12));
                p.getWorld().strikeLightningEffect(loc);
                if (target instanceof LivingEntity living) living.damage(10, p);
                p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 50, .8,.8,.8,.1);
                p.sendMessage(ChatColor.YELLOW + "Divine Lightning!");
            }
            case "invulnerability" -> {
                if (!cooldown(p, power, 35)) return;
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 20*8, 4, true, true));
                p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 20*8, 0, true, true));
                p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0,1,0), 100, 1,1,1,.15);
                p.sendTitle(ChatColor.AQUA + "DIVINE BARRIER", ChatColor.WHITE + "You are protected for 8 seconds", 5, 35, 10);
            }
            case "energy" -> {
                if (!cooldown(p, power, 7)) return;
                Location loc = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(10));
                p.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 100, 1.2,1.2,1.2,.08);
                p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 80, 1,1,1,.12);
                p.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, .8f, 1.5f);
                for (Entity entity : p.getWorld().getNearbyEntities(loc, 3,3,3)) {
                    if (entity instanceof LivingEntity living && entity != p) {
                        living.damage(9, p);
                        Vector knock = entity.getLocation().toVector().subtract(p.getLocation().toVector()).normalize().multiply(1.3);
                        living.setVelocity(knock);
                    }
                }
                p.sendMessage(ChatColor.GOLD + "Destiny Burst!");
            }
            case "strength" -> {
                if (!cooldown(p, power, 25)) return;
                p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20*12, 2, true, true));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20*12, 1, true, true));
                p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0,1,0), 70, .7,.8,.7,.03);
                p.sendMessage(ChatColor.GOLD + "Chosen Might! Strength empowered for 12 seconds.");
            }
            case "regeneration" -> {
                if (!cooldown(p, power, 40)) return;
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 20*10, 2, true, true));
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 20*10, 1, true, true));
                p.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, p.getLocation().add(0,1,0), 80, .8,.8,.8,.1);
                p.sendTitle(ChatColor.GREEN + "FATED RECOVERY", ChatColor.WHITE + "Your vitality returns", 5, 35, 10);
            }
        }
    }
}
